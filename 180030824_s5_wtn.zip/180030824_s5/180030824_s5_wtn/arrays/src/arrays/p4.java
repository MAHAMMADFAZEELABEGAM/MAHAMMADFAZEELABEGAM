package arrays;

public class p4 {  
		 public static void main(String[] args) {
		        int ascii[] = {97,98,99,100,101,102};
		        for (int i = 0; i < ascii.length; i++) {
		            System.out.print((char)ascii[i] + " ");
		        }
		        System.out.println();
		    }
		}