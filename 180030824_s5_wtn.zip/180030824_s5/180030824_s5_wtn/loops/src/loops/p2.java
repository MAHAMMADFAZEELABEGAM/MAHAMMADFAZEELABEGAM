package loops;
import java.util.Scanner;

public class p2
{
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		if(a%2==0)
		{
			System.out.println("the number is "+a +" even");
		}
		else
		{
			System.out.println("the number is "+a +" odd");
		}
		
}
	
}
