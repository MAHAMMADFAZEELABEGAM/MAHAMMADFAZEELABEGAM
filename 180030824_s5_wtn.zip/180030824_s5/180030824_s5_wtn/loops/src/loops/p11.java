package loops;

public class p11 {
	public static void main(String[] args)
    {
	for (int i = 23; i <= 57; i++) {
		   //if number%2 == 0 it means its an even number
		   if (i % 2 == 0) {
			System.out.println(i);
		   }
	}
    }
}
